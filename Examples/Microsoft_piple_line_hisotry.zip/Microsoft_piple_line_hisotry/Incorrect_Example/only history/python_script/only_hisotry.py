import os
import glob
import pandas as pd
import csv

# === CONFIGURATION ===
base_dir = r"D:\ASU WORK\research\Correct"
pipeline_csv = os.path.join(base_dir, "github_pipeline.csv")

# Load the pipeline CSV
pipeline_df = pd.read_csv(pipeline_csv)

# Indices to include (only these will be used)
include_indices = [0, 2, 4, 10, 13, 15, 18, 23, 27, 30, 35, 36, 38, 46, 62, 71, 72, 73, 74, 78]

# Normalize CSV columns
pipeline_df.columns = pipeline_df.columns.str.strip().str.lower()
pipeline_df["file"] = pipeline_df["file"].astype(str).str.strip().str.lower()
pipeline_df["index"] = pd.to_numeric(pipeline_df["index"], errors="coerce")

# Only keep Length9 files that match included indices
length9_files = pipeline_df[pipeline_df["file"].str.startswith("length9_")]
length9_files = length9_files[length9_files["index"].isin(include_indices)]

# === MAIN SCRIPT ===
results = []

# Iterate over all Length9_* directories
for dir_path in glob.glob(os.path.join(base_dir, "Length9_*")):
    length_name = os.path.basename(dir_path)
    matching_file = f"{length_name.lower()}.pkl"

    # Keep only directories present in CSV (included indices only)
    subset = length9_files[length9_files["file"] == matching_file]
    if subset.empty:
        continue

    print(f"📂 Processing {length_name}...")

    # ---- TARGET DATASET ----
    target_path = os.path.join(dir_path, "Target_datasets", "target.csv")
    if not os.path.exists(target_path):
        print(f"  ⚠️ No target file found in {length_name}")
        continue

    target_df = pd.read_csv(target_path)
    target_schema = list(target_df.columns)
    target_examples = target_df.head(2).values.tolist()
    target_examples = [list(map(str, row)) for row in target_examples]

    # ---- SOURCE DATASETS ----
    sources_dir = os.path.join(dir_path, "Source_datasets")
    source_files = glob.glob(os.path.join(sources_dir, "test_*.csv"))

    source_info = []
    for i, src_file in enumerate(source_files):
        src_df = pd.read_csv(src_file)
        src_schema = list(src_df.columns)
        src_examples = src_df.head(2).values.tolist()
        src_examples = [list(map(str, row)) for row in src_examples]

        source_info.append({
            "name": os.path.basename(src_file),
            "schema": src_schema,
            "examples": src_examples
        })

    # ---- BUILD SCRIPT TEXT ----
    script_lines = []
    script_lines.append(f"Example : {length_name}\n")
    script_lines.append(f"Target Table Name : target")
    script_lines.append(f"Target Schema : {target_schema}")
    script_lines.append(f"Target Examples : {target_examples}\n")

    script_lines.append("Multi Source Information :\n")
    for i, s in enumerate(source_info):
        script_lines.append(f"Source {i}:")
        script_lines.append(f"   Source {i} Name: {s['name']}")
        script_lines.append(f"   Source {i} Schema: {s['schema']}")
        script_lines.append(f"   Source {i} Examples: {s['examples']}\n")

    # ---- ADD OPERATION HISTORY ----
    operations = subset["operators"].dropna().astype(str).tolist()
    clean_ops = []
    for op in operations:
        op = op.strip("[]").replace("'", "").replace('"', "")
        for single in op.split(","):
            s = single.strip()
            if s:
                clean_ops.append(s)

    script_lines.append(f"Operation History for this example:")
    for i, op in enumerate(clean_ops):
        script_lines.append(f"   Step {i+1}: {op}")
    script_lines.append("\n")



    # ---- FINALIZE SCRIPT TEXT ----
    final_script = "\n".join(script_lines)

    # ---- STORE INTO RESULTS LIST ----
    results.append({
        "directory": length_name,
        "target_schema": target_schema,
        "target_examples": str(target_examples),
        "num_sources": len(source_info),
        "script": final_script
    })

# ---- CONVERT TO DATAFRAME ----
df = pd.DataFrame(results)

if not df.empty:
    # ---- ESCAPE newlines before saving ----
    df["script"] = (
        df["script"].astype(str)
        .str.replace("\r\n", "\\n", regex=False)
        .str.replace("\r", "\\n", regex=False)
        .str.replace("\n", "\\n", regex=False)
    )

    # ---- SAVE TO CSV ----
    output_csv = os.path.join(base_dir, "length9_correct_all_info_with_ops.csv")
    df.to_csv(output_csv, index=False, encoding="utf-8-sig", quoting=csv.QUOTE_ALL)
    print(f"\n✅ All information saved to {output_csv}")

    # ---- SAVE ALSO AS EXCEL ----
    excel_path = os.path.join(base_dir, "length9_correct_all_info_with_ops.xlsx")
    df_excel = df.copy()
    df_excel["script"] = df_excel["script"].str.replace("\\n", "\n", regex=False)
    df_excel.to_excel(excel_path, index=False, engine="openpyxl")
    print(f"✅ Also saved as Excel: {excel_path}")

    # ---- SAVE INDIVIDUAL SCRIPTS ----
    output_folder = os.path.join(base_dir, "few-shot_correctcases_scripts_with_ops")
    os.makedirs(output_folder, exist_ok=True)

    for i, row in df.iterrows():
        filename = os.path.join(output_folder, f"{row['directory']}.txt")
        with open(filename, "w", encoding="utf-8") as f:
            f.write(row["script"].replace("\\n", "\n"))

    print(f"✅ All individual script files saved inside: {output_folder}")
else:
    print("⚠️ No data processed. Check if included indices exist in github_pipeline.csv.")
