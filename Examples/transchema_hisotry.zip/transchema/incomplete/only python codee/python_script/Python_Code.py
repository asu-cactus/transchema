import os
import glob
import pandas as pd
import csv

# ==== CONFIGURATION ====
base_dir = r"D:\ASU WORK\research\incorrect"
# ========================

# Store all results
results = []

# Iterate over all Length9_* directories
for dir_path in glob.glob(os.path.join(base_dir, "Length9_*")):
    length_name = os.path.basename(dir_path)
    print(f"Processing {length_name}...")

    # ---- TARGET DATASET ----
    target_path = os.path.join(dir_path, "Target_datasets", "target.csv")
    if not os.path.exists(target_path):
        print(f"  ⚠️ No target file found in {length_name}")
        continue

    target_df = pd.read_csv(target_path)
    target_schema = list(target_df.columns)
    target_examples = target_df.head(2).astype(str).values.tolist()

    # ---- SOURCE DATASETS ----
    sources_dir = os.path.join(dir_path, "Source_datasets")
    source_files = glob.glob(os.path.join(sources_dir, "test_*.csv"))

    source_info = []
    for src_file in source_files:
        src_df = pd.read_csv(src_file)
        src_schema = list(src_df.columns)
        src_examples = src_df.head(2).astype(str).values.tolist()

        source_info.append({
            "name": os.path.basename(src_file),
            "schema": src_schema,
            "examples": src_examples
        })

    # ---- BUILD SCRIPT TEXT ----
    script_lines = [
        f"Example : {length_name}\n",
        f"Target Table Name : target",
        f"Target Schema : {target_schema}",
        f"Target Examples : {target_examples}\n",
        "Multi Source Information :\n"
    ]

    for i, s in enumerate(source_info):
        script_lines.extend([
            f"Source {i}:",
            f"   Source {i} Name: {s['name']}",
            f"   Source {i} Schema: {s['schema']}",
            f"   Source {i} Examples: {s['examples']}\n"
        ])

    # ---- Add Python Recovered Code (NO operation history) ----
    recovered_path = os.path.join(dir_path, "python_recovered.py")
    if os.path.exists(recovered_path):
        script_lines.append("\nPython Code:\n")
        with open(recovered_path, "r", encoding="utf-8") as pyfile:
            python_code = pyfile.read()
        script_lines.append(python_code)
    else:
        script_lines.append("\n⚠️ No python_recovered.py found\n")

    final_script = "\n".join(script_lines)

    # ---- STORE RESULT ----
    results.append({
        "directory": length_name,
        "target_schema": target_schema,
        "target_examples": str(target_examples),
        "num_sources": len(source_info),
        "script": final_script
    })

# ---- CONVERT TO DATAFRAME ----
df = pd.DataFrame(results)
df["script"] = df["script"].str.replace("\n", "\\n")

# ---- SAVE TO CSV ----
output_csv = os.path.join(base_dir, "length9_incorrect_python_only.csv")
df.to_csv(output_csv, index=False, encoding="utf-8-sig", quoting=csv.QUOTE_ALL)
print(f"\n✅ All information saved to {output_csv}")

# ---- SAVE TO EXCEL ----
excel_path = os.path.join(base_dir, "length9_incorrect_python_only.xlsx")
df_excel = df.copy()
df_excel["script"] = df_excel["script"].str.replace("\\n", "\n")
df_excel.to_excel(excel_path, index=False, engine="openpyxl")
print(f"✅ Also saved as Excel: {excel_path}")

# ---- SAVE INDIVIDUAL TXT FILES ----
output_folder = os.path.join(base_dir, "incorrect_scripts_python_only")
os.makedirs(output_folder, exist_ok=True)

for _, row in df.iterrows():
    filename = os.path.join(output_folder, f"{row['directory']}.txt")
    with open(filename, "w", encoding="utf-8") as f:
        f.write(row["script"].replace("\\n", "\n"))

print(f"✅ All individual script files (Python code only) saved inside: {output_folder}")
