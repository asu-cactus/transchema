import os
import glob
import pandas as pd
import csv

# base path
base_dir = "Correct_Cases_Length9"

# store results in list
results = []

# iterate over all length9_* directories
for dir_path in glob.glob(os.path.join(base_dir, "Length9_*")):
    length_name = os.path.basename(dir_path)
    print(f"Processing {length_name}...")

    # ---- TARGET DATASET ----
    target_path = os.path.join(dir_path, "Target_datasets", "target.csv")
    if not os.path.exists(target_path):
        print(f"  ⚠️ No target file found in {length_name}")
        continue

    target_df = pd.read_csv(target_path)
    target_schema = list(target_df.columns)
    target_examples = target_df.head(2).values.tolist()
    target_examples = [list(map(str, row)) for row in target_examples]

    # ---- SOURCE DATASETS ----
    sources_dir = os.path.join(dir_path, "Source_datasets")
    source_files = glob.glob(os.path.join(sources_dir, "test_*.csv"))

    source_info = []
    for i, src_file in enumerate(source_files):
        src_df = pd.read_csv(src_file)
        src_schema = list(src_df.columns)
        src_examples = src_df.head(2).values.tolist()
        src_examples = [list(map(str, row)) for row in src_examples]

        source_info.append({
            "name": os.path.basename(src_file),
            "schema": src_schema,
            "examples": src_examples
        })

    # ---- BUILD SCRIPT TEXT ----
    script_lines = []
    script_lines.append(f"Example : {length_name}\n")
    script_lines.append(f"Target Table Name : target")
    script_lines.append(f"Target Schema : {target_schema}")
    script_lines.append(f"Target Examples : {target_examples}\n")

    script_lines.append("Multi Source Information :\n")

    for i, s in enumerate(source_info):
        script_lines.append(f"Source {i}:")
        script_lines.append(f"   Source {i} Name: {s['name']}")
        script_lines.append(f"   Source {i} Schema: {s['schema']}")
        script_lines.append(f"   Source {i} Examples: {s['examples']}\n")

    # Add operation history (assuming union for now)
    source_names = [f"source_{i}" for i in range(len(source_info))]
    script_lines.append(f"Operation History for this example: [UNION : {source_names}]\n")

    final_script = "\n".join(script_lines)

    # ---- STORE INTO RESULTS LIST ----
    results.append({
        "directory": length_name,
        "target_schema": target_schema,
        "target_examples": str(target_examples),
        "num_sources": len(source_info),
        "script": final_script
    })

# ---- CONVERT TO DATAFRAME ----
df = pd.DataFrame(results)

# ---- ESCAPE newlines before saving (prevents cell breakage in Excel) ----
df["script"] = (
    df["script"]
    .astype(str)
    .str.replace("\r\n", "\\n")
    .str.replace("\r", "\\n")
    .str.replace("\n", "\\n")
)

# ---- SAVE TO CSV ----
output_csv = "length9_correct_all_info.csv"

# Now save safely
df.to_csv("length9_correct_all_info.csv", index=False, encoding="utf-8-sig", quoting=csv.QUOTE_ALL)
print(f"\n✅ All information saved to {output_csv}")

# ---- OPTIONAL: also save as Excel for multiline viewing ----
excel_path = "length9_correct_all_info.xlsx"
df_excel = df.copy()
# restore newlines for Excel (Excel supports them)
df_excel["script"] = df_excel["script"].str.replace("\\n", "\n")

df_excel.to_excel(excel_path, index=False, engine="openpyxl")
print(f"✅ Also saved as Excel: {excel_path}")

output_folder = "few-shot_correctcases_scripts"
os.makedirs(output_folder, exist_ok=True)

for i, row in df.iterrows():
    filename = os.path.join(output_folder, f"{row['directory']}.txt")
    with open(filename, "w", encoding="utf-8") as f:
        f.write(row["script"].replace("\\n", "\n"))

print(f"✅ All individual script files saved inside: {output_folder}")
